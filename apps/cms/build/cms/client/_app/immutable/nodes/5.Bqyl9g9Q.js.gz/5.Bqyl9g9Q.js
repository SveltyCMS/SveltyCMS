import{_ as m}from"../chunks/CY0QKx3Q.js";export{m as component};
//# sourceMappingURL=5.Bqyl9g9Q.js.map
