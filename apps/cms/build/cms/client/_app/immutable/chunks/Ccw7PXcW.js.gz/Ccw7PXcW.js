function c(n){const u=n-1;return u*u*u+1}function r(n){return--n*n*n*n*n+1}export{c,r as q};
//# sourceMappingURL=Ccw7PXcW.js.map
