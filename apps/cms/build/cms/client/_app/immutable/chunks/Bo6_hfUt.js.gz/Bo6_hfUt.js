import{j as s,k as t,w as i}from"./DrlZFkx8.js";import{B as k}from"./CTjXDULS.js";function h(a,r,e){t&&i();var n=new k(a);s(()=>{var o=r();n.ensure(o,e)})}export{h as k};
//# sourceMappingURL=Bo6_hfUt.js.map
