import{j as s,G as c,k as m,w as i}from"./DrlZFkx8.js";import{B as p}from"./CTjXDULS.js";function l(n,r,o){m&&i();var e=new p(n);s(()=>{var a=r()??null;e.ensure(a,a&&(t=>o(t,a)))},c)}export{l as c};
//# sourceMappingURL=7bh91wXp.js.map
