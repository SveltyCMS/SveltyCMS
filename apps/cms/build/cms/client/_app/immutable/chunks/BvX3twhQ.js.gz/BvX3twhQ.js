import{D as o}from"./rsSWfq8L.js";import{b as a,v as b}from"./XmViZn7X.js";const r=!0,t=r,e=o;export{t as browser,a as building,e as dev,b as version};
//# sourceMappingURL=BvX3twhQ.js.map
