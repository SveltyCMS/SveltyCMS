var a=(E=>(E.CREATE="create",E.READ="read",E.UPDATE="update",E.DELETE="delete",E.WRITE="write",E.MANAGE="manage",E.SHARE="share",E.ACCESS="access",E.EXECUTE="execute",E))(a||{}),C=(E=>(E.COLLECTION="collection",E.USER="user",E.CONFIGURATION="configuration",E.SYSTEM="system",E.API="api",E))(C||{});export{C as P,a};
//# sourceMappingURL=PsFRGuNZ.js.map
