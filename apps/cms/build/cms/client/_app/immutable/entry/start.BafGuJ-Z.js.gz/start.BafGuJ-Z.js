import{l as o,f as r}from"../chunks/DHPSYX_z.js";export{o as load_css,r as start};
//# sourceMappingURL=start.BafGuJ-Z.js.map
