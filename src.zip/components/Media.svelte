<script lang="ts">
	import type { MediaImage } from '@src/utils/types';
	import { SIZES, formatBytes, debounce } from '@src/utils/utils';
	import axios from 'axios';

	// ParaglideJS
	import * as m from '@src/paraglide/messages';

	let files: MediaImage[] = [];
	let search = '';
	let searchDeb = debounce(500);
	let showInfo = Array.from({ length: files.length }, () => false);

	export let onselect: any = () => {};

	async function refresh() {
		await axios.get('/media/getAll').then((res) => (files = res.data));
	}
	refresh();

	$: {
		searchDeb(() => refresh());
		search;
	}
</script>

{#if files.length === 0}
	<!-- Display a message when no media is found -->
	<div class="mx-auto text-center text-tertiary-500 dark:text-primary-500">
		<iconify-icon icon="bi:exclamation-circle-fill" height="44" class="mb-2" />
		<p class="text-lg">{m.mediagallery_nomedia()}</p>
	</div>
{:else}
	<div class="header flex items-center gap-2">
		<label for="search" class=" ext-tertiary-500 font-bold dark:text-primary-500">Media</label>
		<input type="text" bind:value={search} placeholder="Search" class="input" />
	</div>
	<div class="flex max-h-[calc(100%-55px)] flex-wrap items-center justify-center overflow-auto">
		{#each files as file, index}
			<button on:click={() => onselect(file)} class="card relative flex w-[100%] flex-col md:w-[30%]">
				<div class="absolute flex w-full items-center bg-surface-700">
					<button class="ml-[2px] mt-[2px] block w-[30px]" on:click|stopPropagation={() => (showInfo[index] = !showInfo[index])}>
						<iconify-icon icon="raphael:info" width="25" class="text-tertiary-500"></iconify-icon>
					</button>
					<p class="mx-auto pr-[30px] text-white">{file.thumbnail.name}</p>
				</div>
				{#if !showInfo[index]}
					<img src={file.thumbnail.url} alt={file.thumbnail.name} class="mx-auto mt-auto max-h-[calc(100%-35px)] rounded-md" />
				{:else}
					<table class="mt-[30px] min-h-[calc(100%-30px)] w-full">
						<tbody class="table-compact">
							{#each Object.keys(SIZES) as size}
								<tr>
									<td class="!pl-[10px]">
										{size}
									</td>
									<td>
										{file[size].width}x{file[size].height}
									</td>
									<td>
										{formatBytes(file[size].size)}
									</td>
								</tr>
							{/each}
						</tbody>
					</table>
				{/if}
			</button>
		{/each}
	</div>
{/if}
