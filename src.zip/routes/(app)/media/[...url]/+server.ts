import { publicEnv } from '@root/config/public';
import type { RequestHandler } from './$types';
import fs from 'fs';
import mime from 'mime-types';
import zlib from 'zlib';
import path from 'path'; // Import path module to construct file paths

// TODO: add smarter Cache like lru-cache - A cache object that deletes the least-recently-used items.
const cache = new Map<string, Buffer>();

export const GET: RequestHandler = async ({ params }) => {
	try {
		// Construct the file path
		let fileUrl = path.join(publicEnv.MEDIA_FOLDER, params.url);

		// If MEDIASERVER_URL is set, prepend it to the file path
		if (publicEnv.MEDIASERVER_URL) {
			fileUrl = `${publicEnv.MEDIASERVER_URL}/${fileUrl}`;
		}

		// Check if data is in cache
		let data = cache.get(params.url);
		if (!data) {
			// Read data from file and store in cache
			data = await fs.promises.readFile(fileUrl);
			cache.set(params.url, data);
		}

		// Compress data using Brotli
		const compressedData = zlib.brotliCompressSync(data);
		return new Response(compressedData, {
			headers: {
				'Content-Type': mime.lookup(params.url) as string,
				'Content-Encoding': 'br'
			}
		});
	} catch (err: any) {
		console.error(err);
		if (err.code === 'ENOENT') {
			return new Response('File not found', { status: 404 });
		} else if (err.code === 'EACCES') {
			return new Response('Access denied', { status: 403 });
		} else if (err.code === 'ERR_FS_FILE_TOO_LARGE') {
			return new Response('File too large', { status: 413 });
		} else if (err.code === 'EMFILE') {
			return new Response('Too many open files', { status: 500 });
		} else if (err.code === 'EBUSY') {
			return new Response('Resource busy or locked', { status: 500 });
		} else {
			return new Response('Internal server error', { status: 500 });
		}
	}
};
